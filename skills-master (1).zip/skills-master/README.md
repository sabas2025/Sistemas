# Skills para Claude — +2.300 skills prontas para usar

[![Skills](https://img.shields.io/badge/skills-2.300%2B-blue)](https://github.com/kursku/skills) [![Categorias](https://img.shields.io/badge/categorias-30-green)](https://github.com/kursku/skills) [![PT-BR](https://img.shields.io/badge/idioma-PT--BR-yellow)](https://github.com/kursku/skills)

O [Claude](https://claude.ai) e um assistente de IA da Anthropic. **Skills** sao instrucoes que ensinam o Claude a dominar tarefas especificas — como contratar um especialista sob demanda.

Escolha uma skill de copywriting e o Claude escreve como redator senior. Escolha uma de SEO e ele faz auditorias tecnicas. Escolha uma de funis e ele monta sua estrategia de vendas completa.

---

## Como usar — passo a passo

### Passo 1: Escolha uma skill

Navegue pelas categorias abaixo e clique em **[Ver skill]** para abrir o arquivo `SKILL.md`. Clique em **"Download raw file"** (icone de seta para baixo) para baixar.

![Navegando pelas categorias no GitHub](docs/assets/step0b-github-skills.png)

---

### Passo 2: Abra o Claude e va em Personalizar

No [claude.ai](https://claude.ai), clique em **Personalizar** na sidebar esquerda.

![Menu Personalizar no Claude](docs/assets/step1-personalizar.png)

---

### Passo 3: Va em Habilidades e faca upload

Clique em **Habilidades** → clique no botao **+** → faca upload do arquivo `SKILL.md` que voce baixou.

![Tela de Habilidades](docs/assets/step2-habilidades.png)

![Upload de skill](docs/assets/step3-upload.png)

---

### Passo 4: Use a skill no chat

Volte para o chat. A skill aparece automaticamente — basta digitar **/** ou clicar em **"Vamos la"** para ativar.

![Skill ativa no chat](docs/assets/step4-chat-skill.png)

---

> **Dica:** voce pode adicionar varias skills. Exemplo: junte "meta-ads-campaign" + "ad-creative-brief" + "conversion-tracking" para um projeto completo de trafego pago.

> **Usa Claude Code (terminal)?** Veja [docs/SKILLSHARE.md](docs/SKILLSHARE.md) para instalar via `skillshare install`.

---

## Categorias em Portugues (522 skills)

Skills criadas em portugues, focadas em marketing digital, negocios e estrategia.

| Categoria | Skills | Descricao |
|-----------|:------:|-----------|
| [Conteudo & Copy](./conteudo-copy/) | 32 | Copywriting, headlines, roteiros, posts e materiais persuasivos |
| [Email & Automacao](./email-automacao/) | 32 | Sequencias de email, automacoes, campanhas e nurturing |
| [Funis de Vendas](./funis-vendas/) | 32 | Funis, ofertas, checkout, upsell e estrategia comercial |
| [Anuncios & Trafego](./anuncios-trafego/) | 32 | Meta Ads, Google Ads, TikTok Ads, criativos e tracking |
| [SEO & Busca](./seo-busca/) | 32 | SEO tecnico, conteudo organico, keywords e rankeamento |
| [Financeiro & Precos](./financeiro-precos/) | 32 | Precificacao, projecoes, fluxo de caixa e saude financeira |
| [Juridico & Compliance](./juridico-compliance/) | 32 | Contratos, politicas, LGPD e documentacao juridica |
| [Lancamento & Growth](./lancamento-growth/) | 32 | Growth hacking, aquisicao, retencao e lancamentos |
| [Redes Sociais](./redes-sociais/) | 32 | Conteudo, engajamento e crescimento em redes sociais |
| [Clientes & Consultoria](./clientes-consultoria/) | 32 | Gestao de clientes, onboarding, reporting e consultoria |
| [Operacoes & Sistemas](./operacoes-sistemas/) | 32 | Processos, documentacao, SOPs e gestao operacional |
| [IA & Automacao](./ia-automacao/) | 32 | IA aplicada, agentes, chatbots e integracoes inteligentes |
| [Cursos & Educacao](./cursos-educacao/) | 32 | Cursos online, programas de ensino e produtos educacionais |
| [Marca Pessoal](./marca-pessoal/) | 32 | Autoridade, reputacao, networking e presenca profissional |
| [Analytics & Dados](./analytics-dados/) | 32 | Metricas, dashboards, testes A/B e analise de dados |
| [Nichos Especificos](./nichos-especificos/) | 30 | Marketing para imoveis, saude, educacao, SaaS e mais |
| [Utilitarios Tecnicos](./utilitarios-tecnicos/) | 8 | Integracao, automacao, seguranca e engenharia |
| [Utilitarios de Negocio](./utilitarios-negocio/) | 4 | Atendimento, pesquisa e suporte geral |

---

## Categorias Tecnicas e Importadas (+1.800 skills)

Skills do ecossistema global, focadas em desenvolvimento, infraestrutura e tecnologia.

| Categoria | Skills | Descricao |
|-----------|:------:|-----------|
| [Cloud & DevOps](./cloud-devops/) | 277 | AWS, GCP, Azure, Docker, Kubernetes, CI/CD |
| [Backend](./backend/) | 252 | APIs, bancos de dados, Node.js, Python, Go |
| [Negocios & Growth](./business/) | 231 | Produto, analytics, vendas e operacao |
| [Docs & Conteudo](./docs-content/) | 205 | Documentacao, escrita tecnica e publicacao |
| [Automacao & Integracoes](./automation/) | 145 | Zapier, Make, n8n, integracoes SaaS |
| [Frontend](./frontend/) | 135 | React, Next.js, CSS, acessibilidade e UI/UX |
| [Seguranca](./security/) | 123 | Auditoria, hardening, pentesting e compliance |
| [Dados & IA](./data-ai/) | 99 | LLMs, machine learning, RAG e agentes IA |
| [Mobile](./mobile/) | 65 | React Native, Expo, Flutter, iOS e Android |
| [Fluxos & Orquestracao](./workflow/) | 32 | Planejamento, execucao e gestao de projetos |
| [Games](./game-dev/) | 25 | Unity, Godot, jogos 2D/3D e gameplay |
| [Ferramentas](./tooling/) | 11 | CLIs, ferramentas de dev e utilitarios |

---

## Perguntas frequentes

**Preciso pagar para usar?**
As skills sao gratuitas. Voce so precisa de uma conta no [claude.ai](https://claude.ai) (tem plano gratuito).

**Funciona no celular?**
Sim! O claude.ai funciona no navegador do celular. Adicione as skills pelo computador e use em qualquer lugar.

**Posso usar varias skills ao mesmo tempo?**
Sim. Adicione quantas quiser — elas ficam disponiveis em todos os seus chats.

**As skills funcionam no ChatGPT ou Gemini?**
Foram feitas para o Claude, mas o conteudo do SKILL.md pode ser adaptado como instrucao em qualquer IA.

---

## Crie sua propria skill

Quer ensinar o Claude algo novo? Veja o **[guia completo de como criar uma skill](./docs/COMO_CRIAR_SKILL.md)** — com exemplos reais, dicas de escrita e template pronto para usar.

---

## Contribuindo

1. Faca um fork do repositorio
2. Crie sua skill seguindo o [guia](./docs/COMO_CRIAR_SKILL.md)
3. Abra um Pull Request

Veja tambem: [padrao de qualidade](./docs/QUALITY_BAR.md) | [anatomia de uma skill](./docs/SKILL_ANATOMY.md) | [template](./docs/SKILL_TEMPLATE.md)

Duvidas? Abra uma [issue](https://github.com/kursku/skills/issues).
